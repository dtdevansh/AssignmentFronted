import './App.css';
import PieChart from './components/PieChart';
import BarGraph from './components/BarGraph';
import LineChart from './components/LineChart';
import AreaPlot from './components/AreaPlot';
import ScatterPlot from './components/ScatterPlot'; 
import BarChartStacked from './components/BarChartStacked.js';
import

function App() {
  return (

    <div className='Page'> 
    <div className='logo'> <img src="/logo.png" alt="Logo" /></div>
    <div className='FilterBar'>

    </div>
    <div className='Charts'>
    <div className='Row1'>
    <div className='LineChart'><LineChart/></div>
    <div className='PieChart'><PieChart /></div>
    <div className='ResearchBar'> <BarGraph/></div>
    </div>
    <div className='Row2'>
      <div className='AreaPlot'><AreaPlot/></div>
      </div>
    <div className='Row3'>
    <div className='ScatterPlot'><ScatterPlot/></div>
    </div>
    <div className='Row4'>
    <div className='StackedBar'><BarChartStacked/></div>
    </div>
    </div>
    </div>
    
   

  );
}

export default App;
