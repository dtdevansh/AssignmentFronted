import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const ScatterPlot = () => {
  const svgRef = useRef();
  const data = [
    { x: 10, y: 20, size: 30 },
    { x: 15, y: 25, size: 20 },
    { x: 20, y: 30, size: 25 },
    { x: 25, y: 35, size: 15 },
    { x: 30, y: 40, size: 35 },
    { x: 40, y: 40, size: 20 }
  ];
  const width='400';
  const height='250';

  useEffect(() => {
    if (!data || data.length === 0) return;

    const svg = d3.select(svgRef.current);

    // Define margins
    const margin = { top: 10, right: 30, bottom: 30, left: 40 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Define scales
    const xScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.x)])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.y)])
      .nice()
      .range([innerHeight, 0]);

    const sizeScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.size)]) // Assuming size is another variable
      .range([4, 20]); // Adjust the range of sizes as needed

    // Draw data points
    svg.selectAll("circle")
      .data(data)
      .enter()
      .append("circle")
      .attr("cx", d => xScale(d.x))
      .attr("cy", d => yScale(d.y))
      .attr("r", d => sizeScale(d.size)) // Use sizeScale to determine the radius
      .attr("fill", "steelblue") // Set the color of the data points
      .attr("opacity", 0.7); // Set the opacity of the data points

    // Draw x-axis
    svg.append("g")
       .attr("transform", `translate(0, ${innerHeight})`)
      .call(d3.axisBottom(xScale));

    // Draw y-axis
    svg.append("g")
      .call(d3.axisRight(yScale));
  }, [data, width, height]);

  return (
    <svg ref={svgRef} width={width} height={height}>
      {/* Data points, x-axis, and y-axis will be drawn here */}
    </svg>
  );
};

export default ScatterPlot;
