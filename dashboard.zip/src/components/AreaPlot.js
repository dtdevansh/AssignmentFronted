import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const AreaPlot = () => {
  const svgRef = useRef();

  const data = [
    { x: 0, y1: 10, y2: 20, y3: 30, y4: 25 },
    { x: 1, y1: 15, y2: 25, y3: 20, y4: 10 },
    { x: 2, y1: 20, y2: 30, y3: 25, y4: 30 },
    { x: 3, y1: 25, y2: 35, y3: 30, y4: 20 },
    { x: 4, y1: 30, y2: 20, y3: 35, y4: 25 }
  ];
  const width = 1000;
  const height = 220;

  useEffect(() => {
    if (!data || data.length === 0) return;

    const svg = d3.select(svgRef.current);
    console.log(svgRef.current); 

    // Define margins
    const margin = { top: 20, right: 40, bottom: 30, left: 40 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Define scales
    const xScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.x)]) // Assuming x values are numeric
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => Math.max(d.y1, d.y2, d.y3, d.y4))]) // Assuming y values are numeric
      .nice()
      .range([innerHeight, 0]);

    // Define area generators
    const area1 = d3.area()
      .x(d => xScale(d.x))
      .y0(innerHeight)
      .y1(d => yScale(d.y1));

    const area2 = d3.area()
      .x(d => xScale(d.x))
      .y0(innerHeight)
      .y1(d => yScale(d.y2));

    const area3 = d3.area()
      .x(d => xScale(d.x))
      .y0(innerHeight)
      .y1(d => yScale(d.y3));

    const area4 = d3.area()
      .x(d => xScale(d.x))
      .y0(innerHeight)
      .y1(d => yScale(d.y4));

    // Draw areas
    svg.append("path")
      .datum(data)
      .attr("fill", "#ac00e6")
      .attr("d", area1);

    svg.append("path")
      .datum(data)
      .attr("fill", "#cc33ff")
      .attr("d", area2);

    svg.append("path")
      .datum(data)
      .attr("fill", "#df80ff")
      .attr("d", area3);

    svg.append("path")
      .datum(data)
      .attr("fill", "#f2ccff")
      .attr("d", area4);

    // Draw x-axis
    svg.append("g")
      .attr("transform", `translate(0, ${innerHeight})`)
      .call(d3.axisBottom(xScale));

    // Draw y-axis
    svg.append("g")
      .call(d3.axisRight(yScale))
      .selectAll("text")
      .attr("dy", "0.35em"); // Adjust the vertical position of the numbers
  }, [data, width, height]);

  return (
    <svg ref={svgRef} width={width} height={height}>
      {/* Axes and areas will be drawn here */}
    </svg>
  );
};

export default AreaPlot;
