import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

const PieChart = () => {
  const svgRef = useRef();
  const data = [{
    name: "<5",
    value: 19912018
  },
  {
    name: "5-9",
    value: 20501982
  },
   {
    name: "10-14",
    value: 20679786
  },
  {
    name: "15-19",
    value: 21354481
  },
  {
    name: "20-24",
    value: 22604232
  },
  {
    name: "25-29",
    value: 21698010
  }];


  useEffect(() => {
    const width = 200;
    const height = 200;
    const radius = Math.min(width, height) / 2;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    const color = d3.scaleOrdinal(d3.schemeCategory10);

    const pie = d3.pie()
      .value(d => d.value);

    const arc = d3.arc()
      .innerRadius(radius * 0.6) // Adjust the inner radius for the donut shape
      .outerRadius(radius);

    const arcs = svg.selectAll('arc')
      .data(pie(data))
      .enter()
      .append('g')
      .attr('class', 'arc');

    arcs.append('path')
      .attr('d', arc)
      .attr('fill', (d, i) => color(i));

    arcs.append('text')
      .attr('transform', d => `translate(${arc.centroid(d)})`)
      .attr('text-anchor', 'middle')
      .text(d => d.data.name);
  }, [data]);

  return (
    <svg ref={svgRef}></svg>
  );
};

export default PieChart;
