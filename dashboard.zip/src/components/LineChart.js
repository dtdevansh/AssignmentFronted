import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const LineChart = () => {
  const svgRef = useRef();
  const data = [10, 20, 15, 25, 30, 35];
  const width = 400;
  const height = 200;

  useEffect(() => {
    if (!data || data.length === 0) return;

    const svg = d3.select(svgRef.current);

    const margin = { top: 20, right: 30, bottom: 30, left: 40 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const xScale = d3.scaleLinear()
      .domain([0, data.length - 1])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data)])
      .nice()
      .range([innerHeight, 0]);

    const line = d3.line()
      .x((d, i) => xScale(i))
      .y(d => yScale(d));

    svg.select('.line')
      .datum(data)
      .attr('d', line)
      .attr('fill', 'none')
      .attr('stroke', 'steelblue')
      .attr('stroke-width', 2);

    svg.select('.x-axis')
      .attr('transform', `translate(0, ${innerHeight})`)
      .call(d3.axisBottom(xScale));

    svg.select('.y-axis')
      .call(d3.axisRight(yScale)
        .ticks(5) // Adjust the number of ticks as needed
      )
      .selectAll("text")
      .style("font-size", "10px"); // Adjust font size as needed
  }, [data, width, height]);

  return (
    <svg ref={svgRef} width={width} height={height}>
      <g className="x-axis" />
      <g className="y-axis" />
      <path className="line" />
    </svg>
  );
};

export default LineChart;
