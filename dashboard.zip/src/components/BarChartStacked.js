import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const BarChartStacked = () => {
  const svgRef = useRef();

  const data = [
    { category: "Category 1", group1: 10, group2: 20, group3: 30, group4: 40 },
    { category: "Category 2", group1: 15, group2: 25, group3: 35, group4: 45 },
    { category: "Category 3", group1: 20, group2: 30, group3: 40, group4: 50 },
    { category: "Category 4", group1: 25, group2: 35, group3: 45, group4: 55 },
    { category: "Category 5", group1: 30, group2: 40, group3: 50, group4: 60 },
    { category: "Category 6", group1: 35, group2: 45, group3: 55, group4: 65 },
    { category: "Category 7", group1: 40, group2: 50, group3: 60, group4: 70 },
    { category: "Category 8", group1: 45, group2: 55, group3: 65, group4: 75 },
    { category: "Category 9", group1: 50, group2: 60, group3: 70, group4: 80 },
    { category: "Category 10", group1: 55, group2: 65, group3: 75, group4: 85 },
    { category: "Category 11", group1: 60, group2: 70, group3: 80, group4: 90 },
    { category: "Category 12", group1: 65, group2: 75, group3: 85, group4: 95 },
    { category: "Category 13", group1: 70, group2: 80, group3: 90, group4: 100 },
    { category: "Category 14", group1: 75, group2: 85, group3: 95, group4: 105 },
    { category: "Category 15", group1: 80, group2: 90, group3: 100, group4: 110 },
    { category: "Category 16", group1: 85, group2: 95, group3: 105, group4: 115 },
    { category: "Category 17", group1: 90, group2: 100, group3: 110, group4: 120 },
    { category: "Category 18", group1: 95, group2: 105, group3: 115, group4: 125 },
    { category: "Category 19", group1: 100, group2: 110, group3: 120, group4: 130 },
    { category: "Category 20", group1: 105, group2: 115, group3: 125, group4: 135 }
  ];
  const width='1200';
  const height='220';
  
  useEffect(() => {
    if (!data || data.length === 0) return;

    const svg = d3.select(svgRef.current);

    const margin = { top: 20, right: 30, bottom: 30, left: 40 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const xScale = d3.scaleBand()
      .domain(data.map(d => d.category))
      .range([0, innerWidth])
      .padding(0.1);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.group1 + d.group2 + d.group3 + d.group4)])
        .nice()
      .range([innerHeight, 0]);

    const color = d3.scaleOrdinal()
      .domain(['group1', 'group2', 'group3', 'group4'])
      .range(d3.schemeCategory10);

    svg.selectAll("*").remove(); // Clear previous elements

    const stack = d3.stack()
      .keys(['group1', 'group2', 'group3', 'group4'])
      .order(d3.stackOrderNone)
      .offset(d3.stackOffsetNone);

    const series = stack(data);

    svg.append("g")
      .selectAll("g")
      .data(series)
      .join("g")
        .attr("fill", d => color(d.key))
      .selectAll("rect")
      .data(d => d)
      .join("rect")
        .attr("x", d => xScale(d.data.category))
        .attr("y", d => yScale(d[1]))
        .attr("height", d => yScale(d[0]) - yScale(d[1]))
        .attr("width", xScale.bandwidth());

    svg.append("g")
      .attr("transform", `translate(0, ${innerHeight})`)
      .call(d3.axisBottom(xScale));

    svg.append("g")
      .call(d3.axisLeft(yScale));

  }, [data, width, height]);

  return (
    <svg ref={svgRef} width={width} height={height}>
      {/* Bars will be drawn here */}
    </svg>
  );
};

export default BarChartStacked;
