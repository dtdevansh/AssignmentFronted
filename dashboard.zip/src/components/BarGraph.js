import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

const BarGraph = () => {
  const svgRef = useRef();
  const data = [30, 40, 50, 60, 70, 80, 20, 100, 85, 120, 115];

  useEffect(() => {
    if (!data || data.length === 0) return; // Check if data array is empty

    const svg = d3.select(svgRef.current);

    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const width = +svg.attr("width") - margin.left - margin.right;
    const height = +svg.attr("height") - margin.top - margin.bottom;

    const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

    const x = d3.scaleBand()
      .rangeRound([0, width])
      .padding(0.1)
      .domain(data.map((d, i) => i));

    const y = d3.scaleLinear()
      .rangeRound([height, 0])
      .domain([0, d3.max(data)]);

    g.selectAll(".bar")
      .data(data)
      .enter().append("rect")
      .attr("class", "bar")
      .attr("x", (d, i) => x(i))
      .attr("y", d => y(d))
      .attr("width", x.bandwidth())
      .attr("height", d => height - y(d));

    g.append("g")
      .attr("class", "axis")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x));

    g.append("g")
      .attr("class", "axis")
      .call(d3.axisLeft(y).ticks(5));

    return () => {
      svg.selectAll("*").remove(); 
    };

  }, [data]);

  return (<svg ref={svgRef} width="300" height="200"></svg>
);
};

export default BarGraph;
